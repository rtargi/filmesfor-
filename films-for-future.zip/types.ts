
export interface Dossier {
  title: string;
  description: string;
  url: string;
}
