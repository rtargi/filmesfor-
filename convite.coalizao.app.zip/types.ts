export interface DossierCardProps {
  title: string;
  description: string;
  href: string;
}

export interface StrategicAxis {
  title: string;
  description: string;
}